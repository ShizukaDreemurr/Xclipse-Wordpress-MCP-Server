# vangbacsanhghi-mcp

MCP server (stdio) cho phép Claude quản lý WordPress/WooCommerce của vangbacsanhghi.com
qua REST namespace `vbsg-mcp/v1` của plugin PHP đi kèm.

## Cài đặt
```bash
cd mcp-server
npm install
npm run check   # kiểm tra cú pháp
npm start       # chạy server stdio
```
Yêu cầu Node >= 18.

## Cấu hình (.env)
Tạo `mcp-server/.env` (hoặc truyền qua biến môi trường của client MCP):
```
VBSG_URL=https://vangbacsanhghi.com
VBSG_API_KEY=your-secret-key
VBSG_TIMEOUT_MS=30000
VBSG_MAX_OUT=20000
VBSG_TOOLS=core,woo,seo
```
- `VBSG_URL`, `VBSG_API_KEY`: bắt buộc.
- `VBSG_TIMEOUT_MS`: timeout mỗi request (ms).
- `VBSG_MAX_OUT`: số ký tự tối đa của kết quả trả về, quá sẽ bị cắt.
- `VBSG_TOOLS`: chỉ nạp các nhóm tool liệt kê (để trống = tất cả). Nhóm:
  `core, woo, seo, elementor, flatsome, cache, pixta, forms, mail`.

## Chạy test
```bash
npm test
```
Smoke test tự dựng server giả, không cần site thật. Kiểm tra: số lượng tool (>= 380),
tên không trùng, có inputSchema, gọi thử `site_info`, `posts_list`, `wpms_status`,
và lỗi HTML 502 phải trả `isError` mà không làm client chết. Thoát mã khác 0 nếu có mục FAIL.
