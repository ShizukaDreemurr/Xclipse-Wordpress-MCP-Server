    // ── v4.9.0: ACF, media base64, WP Mail SMTP ──
    $r('/media/upload-base64', 'POST', 'vbsg_media_upload_base64');
    $r('/acf/groups', 'GET', 'vbsg_acf_groups');
    $r('/acf/groups/(?P<group_key>group_[a-z0-9]+)/fields', 'GET', 'vbsg_acf_group_fields');
    $r('/acf/(?P<id>\d+)', 'GET', 'vbsg_acf_get');
    $r('/acf/(?P<id>\d+)', 'PUT', 'vbsg_acf_set');
    $r('/acf/(?P<id>\d+)/fields', 'GET', 'vbsg_acf_fields');
    $r('/wpms/status', 'GET', 'vbsg_wpms_status');
    $r('/wpms/mailers', 'GET', 'vbsg_wpms_mailers');
    $r('/wpms/settings', 'GET', 'vbsg_wpms_settings_get');
    $r('/wpms/settings', 'PUT', 'vbsg_wpms_settings_set');
    $r('/wpms/test-email', 'POST', 'vbsg_wpms_test_email');
    $r('/wpms/debug-events', 'GET', 'vbsg_wpms_debug_events');
    $r('/wpms/debug-events', 'DELETE', 'vbsg_wpms_debug_events_delete');
    $r('/wpms/debug-events/(?P<id>\d+)', 'GET', 'vbsg_wpms_debug_event_get');
    $r('/wpms/send-errors', 'GET', 'vbsg_wpms_send_errors');
    $r('/wpms/send-errors', 'DELETE', 'vbsg_wpms_send_errors_clear');
