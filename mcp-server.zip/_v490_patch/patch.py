import os,re,sys
root=os.path.expanduser(sys.argv[1]); here=os.path.dirname(os.path.abspath(__file__))
rd=lambda p:open(p,encoding='utf-8').read()
def wr(p,s):open(p,'w',encoding='utf-8',newline='').write(s)
P=root+'/vbsg-mcp-api/'; main=P+'vangbac-mcp-api.php'
# includes
for f in('acf.php','wpmailsmtp.php'):
    open(P+'includes/'+f,'w',encoding='utf-8',newline='').write(rd(here+'/'+f))
# media
m=P+'includes/media.php';s=rd(m)
if 'vbsg_media_upload_base64' not in s: wr(m,s.rstrip()+"\n"+rd(here+'/media_b64.php'))
# main
s=rd(main)
if 'wpmailsmtp.php' not in s:
    s=re.sub(r"(require_once[^\n]*batch\.php[^\n]*\n)",r"\1require_once __DIR__ . '/includes/acf.php';        // v4.9.0\nrequire_once __DIR__ . '/includes/wpmailsmtp.php'; // v4.9.0\n",s,1)
    i=s.rindex('});'); s=s[:i]+rd(here+'/routes.php')+s[i:]
s=s.replace('Version:     4.8.0','Version:     4.9.0').replace("'VBSG_MCP_VERSION', '4.8.0'","'VBSG_MCP_VERSION', '4.9.0'"); wr(main,s)
# node
n=root+'/mcp-server/src/index.js';s=rd(n)
if 'wpms_status' not in s:
    k='const transport = new StdioServerTransport();'
    s=s.replace(k,rd(here+'/node_tools.js')+k,1)
s=s.replace("version: '4.8.0'","version: '4.9.0'").replace('[VBSG v4.8.0]','[VBSG v4.9.0]'); wr(n,s)
print('ok')
