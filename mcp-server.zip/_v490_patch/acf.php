<?php
/**
 * ACF tools v4.9.0 — đọc/ghi custom field qua API của ACF (đúng format, kèm field key).
 * Yêu cầu ACF hoặc ACF Pro active.
 */
defined('ABSPATH') || exit;

function vbsg_acf_guard() {
    return function_exists('get_field') && function_exists('update_field')
        ? null : vbsg_err('acf_inactive', 'ACF chưa cài hoặc chưa active', 400);
}

function vbsg_acf_groups(WP_REST_Request $r) {
    if ($e = vbsg_acf_guard()) return $e;
    $groups = function_exists('acf_get_field_groups') ? acf_get_field_groups() : [];
    $out = [];
    foreach ($groups as $g) {
        $out[] = vbsg_compact([
            'key'      => $g['key'],
            'title'    => $g['title'],
            'active'   => !empty($g['active']),
            'location' => $g['location'] ?? [],
            'fields'   => function_exists('acf_get_fields') ? count((array) acf_get_fields($g['key'])) : null,
        ]);
    }
    return vbsg_ok(['count' => count($out), 'groups' => $out]);
}

function vbsg_acf_field_brief(array $f): array {
    $o = vbsg_compact([
        'key'      => $f['key'] ?? '',
        'name'     => $f['name'] ?? '',
        'label'    => $f['label'] ?? '',
        'type'     => $f['type'] ?? '',
        'required' => !empty($f['required']),
        'choices'  => $f['choices'] ?? null,
    ]);
    if (!empty($f['sub_fields'])) $o['sub_fields'] = array_map('vbsg_acf_field_brief', $f['sub_fields']);
    if (!empty($f['layouts']))    $o['layouts'] = array_values(array_map(function ($l) {
        return ['name' => $l['name'] ?? '', 'sub_fields' => array_map('vbsg_acf_field_brief', $l['sub_fields'] ?? [])];
    }, $f['layouts']));
    return $o;
}

function vbsg_acf_group_fields(WP_REST_Request $r) {
    if ($e = vbsg_acf_guard()) return $e;
    $fields = acf_get_fields($r['group_key']);
    if (!$fields) return vbsg_err('not_found', 'Không có field group ' . $r['group_key'], 404);
    return vbsg_ok(['group' => $r['group_key'], 'fields' => array_map('vbsg_acf_field_brief', $fields)]);
}

/** Field group áp dụng cho post (theo location rules). */
function vbsg_acf_fields(WP_REST_Request $r) {
    if ($e = vbsg_acf_guard()) return $e;
    $id = (int) $r['id'];
    if (!get_post($id)) return vbsg_err('not_found', 'Không có post #' . $id, 404);
    $out = [];
    foreach (acf_get_field_groups(['post_id' => $id]) as $g) {
        $out[] = ['group' => $g['key'], 'title' => $g['title'], 'fields' => array_map('vbsg_acf_field_brief', (array) acf_get_fields($g['key']))];
    }
    return vbsg_ok(['post_id' => $id, 'groups' => $out]);
}

function vbsg_acf_get(WP_REST_Request $r) {
    if ($e = vbsg_acf_guard()) return $e;
    $id = (int) $r['id'];
    if (!get_post($id)) return vbsg_err('not_found', 'Không có post #' . $id, 404);
    $format = filter_var($r['format'] ?? true, FILTER_VALIDATE_BOOLEAN);
    $vals = get_fields($id, $format);
    return vbsg_ok(['post_id' => $id, 'formatted' => $format, 'fields' => $vals ?: new stdClass()]);
}

function vbsg_acf_set(WP_REST_Request $r) {
    if ($e = vbsg_acf_guard()) return $e;
    $id = (int) $r['id'];
    if (!get_post($id)) return vbsg_err('not_found', 'Không có post #' . $id, 404);
    $b = $r->get_json_params();
    $fields = is_array($b) && isset($b['fields']) && is_array($b['fields']) ? $b['fields'] : null;
    if (!$fields) return vbsg_err('bad_request', 'Cần "fields": {tên_field: giá_trị}', 400);

    $ok = []; $fail = [];
    foreach ($fields as $name => $val) {
        $name = (string) $name;
        $ref  = function_exists('acf_get_field') ? acf_get_field($name) : null;
        $sel  = $ref ? $ref['key'] : $name;
        if (!$ref && !get_post_meta($id, '_' . $name, true)) {
            $fail[] = $name . ' (field chưa khai báo trong ACF)';
            continue;
        }
        if (update_field($sel, $val, $id) !== false) $ok[] = $name; else $fail[] = $name;
    }
    return vbsg_ok(['post_id' => $id, 'updated' => $ok, 'failed' => $fail]);
}
