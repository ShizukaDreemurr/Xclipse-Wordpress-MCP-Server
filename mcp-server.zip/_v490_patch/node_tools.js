// ── v4.9.0: ACF, media base64, WP Mail SMTP ──
server.tool('media_upload_base64', 'Upload ảnh từ base64 (data URI hoặc chuỗi thuần) vào thư viện.', {
  data: z.string().describe('base64'), filename: z.string().describe('vd: anh.jpg'),
  title: z.string().optional(), alt: z.string().optional(), post_id: z.number().default(0),
}, async (b) => j(await api('/media/upload-base64', 'POST', b)));

server.tool('acf_groups', 'Liệt kê ACF field groups.', {}, async () => j(await api('/acf/groups')));
server.tool('acf_group_fields', 'Field của 1 group (group_key dạng group_xxx).', { group_key: z.string() },
  async ({ group_key }) => j(await api(`/acf/groups/${group_key}/fields`)));
server.tool('acf_fields', 'Các field ACF áp dụng cho 1 post.', { id: z.number() }, async ({ id }) => j(await api(`/acf/${id}/fields`)));
server.tool('acf_get', 'Đọc giá trị ACF của post.', { id: z.number(), format: z.boolean().default(true) },
  async ({ id, format }) => j(await api(`/acf/${id}?format=${format}`)));
server.tool('acf_set', 'Ghi giá trị ACF: fields = {tên_field: giá_trị}.', { id: z.number(), fields: z.record(z.any()) },
  async ({ id, fields }) => j(await api(`/acf/${id}`, 'PUT', { fields })));

server.tool('wpms_status', 'WP Mail SMTP: tình trạng, mailer, cấu hình đủ chưa, lỗi gần nhất, cảnh báo.', {}, async () => j(await api('/wpms/status')));
server.tool('wpms_mailers', 'WP Mail SMTP: danh sách mailer và các field cần.', {}, async () => j(await api('/wpms/mailers')));
server.tool('wpms_settings_get', 'WP Mail SMTP: đọc cấu hình (secret bị che).', {}, async () => j(await api('/wpms/settings')));
server.tool('wpms_settings_set', 'WP Mail SMTP: sửa cấu hình, merge an toàn. settings={mail:{mailer,from_email,...},smtp:{host,port,encryption,auth,user,pass},...}. dry_run=true để xem trước.', {
  settings: z.record(z.record(z.any())), dry_run: z.boolean().default(false),
}, async (b) => j(await api('/wpms/settings', 'PUT', b)));
server.tool('wpms_test_email', 'WP Mail SMTP: gửi mail thử, trả lỗi + debug events phát sinh.', {
  to: z.string().describe('email nhận'), html: z.boolean().default(true),
}, async (b) => j(await api('/wpms/test-email', 'POST', b)));
server.tool('wpms_debug_events', 'WP Mail SMTP: danh sách debug events (đã scrub secret).', {
  type: z.enum(['all', 'error', 'debug']).default('all'), search: z.string().optional(), since: z.string().optional(),
  limit: z.number().default(20), offset: z.number().default(0), max_chars: z.number().default(1500),
}, async (q) => j(await api('/wpms/debug-events?' + qs(q))));
server.tool('wpms_debug_event_get', 'WP Mail SMTP: 1 debug event đầy đủ.', { id: z.number() }, async ({ id }) => j(await api(`/wpms/debug-events/${id}`)));
server.tool('wpms_debug_events_delete', 'WP Mail SMTP: xoá events theo ids, hoặc all+confirm.', {
  ids: z.array(z.number()).optional(), all: z.boolean().optional(), confirm: z.boolean().optional(),
}, async (b) => j(await api('/wpms/debug-events', 'DELETE', b)));
server.tool('wpms_send_errors', 'WP Mail SMTP: lỗi gửi mail theo connection.', {}, async () => j(await api('/wpms/send-errors')));
server.tool('wpms_send_errors_clear', 'WP Mail SMTP: xoá lỗi gửi mail.', { connection_id: z.string().optional() },
  async (b) => j(await api('/wpms/send-errors', 'DELETE', b)));

