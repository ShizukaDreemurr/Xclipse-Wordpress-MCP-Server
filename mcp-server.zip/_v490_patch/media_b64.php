
// ── v4.9.0: upload ảnh dạng base64 ──
function vbsg_media_upload_base64(WP_REST_Request $r) {
    $b = $r->get_json_params();
    $b = is_array($b) ? $b : [];
    $data = (string) ($b['data'] ?? '');
    $name = sanitize_file_name((string) ($b['filename'] ?? 'upload.jpg'));
    if ($data === '') return vbsg_err('bad_request', 'Thiếu "data" (base64)', 400);
    if (preg_match('/^data:[^;]+;base64,/', $data)) $data = preg_replace('/^data:[^;]+;base64,/', '', $data);
    $bin = base64_decode($data, true);
    if ($bin === false || $bin === '') return vbsg_err('bad_base64', 'base64 không hợp lệ', 400);
    if (strlen($bin) > 15 * 1024 * 1024) return vbsg_err('too_large', 'Tối đa 15MB', 413);

    $ft = wp_check_filetype($name);
    if (empty($ft['type']) || strpos($ft['type'], 'image/') !== 0 && $ft['type'] !== 'application/pdf')
        return vbsg_err('bad_type', 'Chỉ cho phép ảnh/PDF (theo đuôi filename)', 400);

    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $up = wp_upload_bits($name, null, $bin);
    if (!empty($up['error'])) return vbsg_err('upload_failed', $up['error'], 500);

    $att = wp_insert_attachment([
        'post_mime_type' => $ft['type'],
        'post_title'     => sanitize_text_field($b['title'] ?? pathinfo($name, PATHINFO_FILENAME)),
        'post_status'    => 'inherit',
    ], $up['file'], (int) ($b['post_id'] ?? 0));
    if (is_wp_error($att)) return vbsg_err('insert_failed', $att->get_error_message(), 500);

    wp_update_attachment_metadata($att, wp_generate_attachment_metadata($att, $up['file']));
    if (!empty($b['alt'])) update_post_meta($att, '_wp_attachment_image_alt', sanitize_text_field($b['alt']));
    return vbsg_ok(['id' => $att, 'url' => wp_get_attachment_url($att), 'mime' => $ft['type']]);
}
