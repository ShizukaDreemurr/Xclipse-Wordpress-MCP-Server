# Dùng: python3 fix_php74.py <thư mục vbsg-mcp-api>   — bỏ kiểu `mixed` (PHP 8.0+) để chạy được PHP 7.4
import re,sys,glob,os
root=sys.argv[1];n=0
for f in glob.glob(os.path.join(root,'**','*.php'),recursive=True):
    if 'fuse_hidden' in f: continue
    s=open(f,encoding='utf-8').read();o=s
    s=re.sub(r'\)\s*:\s*\??mixed(\s*\{)',r')\1',s)
    s=re.sub(r'\(\s*\??mixed\s+(\$\w+)',r'(\1',s)
    s=re.sub(r',\s*\??mixed\s+(\$\w+)',r', \1',s)
    if s!=o: open(f,'w',encoding='utf-8',newline='').write(s);n+=1;print('fixed',f)
print('files',n)
